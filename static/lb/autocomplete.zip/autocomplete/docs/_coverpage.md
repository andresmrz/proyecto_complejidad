<a href="https://tarekraafat.github.io/autoComplete.js/demo/">
	<img src="./img/autoComplete.js.svg" alt= "autoComplete.js Logo" style="padding-bottom: 50px; width: 250px;">
</a>

> Simple autocomplete pure vanilla Javascript library. <a href="https://tarekraafat.github.io/autoComplete.js/demo/" target="\_blank">Live Demo</a> **v7.0**

autoComplete.js is a simple pure vanilla Javascript library that's progressively designed for speed,<br>high versatility and seamless integration with a wide range of projects & systems.

<a href="https://www.producthunt.com/posts/autocomplete-js?utm_source=badge-top-post-badge&utm_medium=badge&utm_souce=badge-autocomplete-js" target="_blank"><img src="https://api.producthunt.com/widgets/embed-image/v1/top-post-badge.svg?post_id=141833&theme=light&period=weekly" alt="autoComplete.js - Simple autocomplete pure vanilla Javascript library. | Product Hunt Embed" style="width: 250px; height: 54px;" width="250px" height="54px" /></a>

<br>

<div class="sharethis-inline-share-buttons"></div>

<a class="github-button" href="https://github.com/TarekRaafat/autoComplete.js" data-icon="octicon-star" data-size="large" data-show-count="true" aria-label="Star tarekraafat/autoComplete.js on GitHub">Star</a>

[GitHub](https://github.com/TarekRaafat/autoComplete.js)
[Get Started](#introduction)

![color](#fff)
